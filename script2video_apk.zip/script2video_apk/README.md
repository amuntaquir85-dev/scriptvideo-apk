# ScriptVideo APK builder

Ye project aapki deploy ki hui website ko Android app (APK) me lapet deta hai.
Pehle website Render par deploy honi chahiye (https link ke saath).

## Steps
1. github.com par naya repository banayein (jaise `scriptvideo-apk`).
2. Is folder ki saari files upload karein. `.github` folder bhi upload hona chahiye.
3. Repo me **Actions** tab -> **Build APK** -> **Run workflow**.
4. Apni website ka link daalein (jaise https://aapka-app.onrender.com) aur Run dabayein.
5. 5-8 minute baad run complete hoga. Us run par jayein, neeche **Artifacts** me
   **ScriptVideo-APK** download karein (zip hai, extract karne par app-debug.apk milega).
6. APK phone me bhejein aur install karein.

## Realme par install
- File Manager me APK kholein. "Install unknown apps" ki permission maangega, allow karein.
- Agar "Blocked by Play Protect" aaye to "Install anyway" dabayein.
